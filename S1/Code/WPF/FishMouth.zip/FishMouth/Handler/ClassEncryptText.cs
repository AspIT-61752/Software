﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Handler
{
    public class ClassEncryptText
    {
        private List<string> key;
        private ClassDecryptText CDT;

        public ClassEncryptText(List<string> inKey)
        {
            // TODO: Add functionality here
        }

        public string EncryptString(string inString)
        {
            return "";
        }

        private void MakeCodeOfChar(char aChar)
        {
            // TODO: Add functionality here
        }
    }
}
