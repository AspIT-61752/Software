﻿using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IO;

namespace Handler
{
    public class ClassHandler
    {
        private ClassFileHandler fileIO;
        private ClassZIP zip;

        ClassHandler()
        {
            fileIO = new ClassFileHandler();
            zip = new ClassZIP();
        }

        public string clearText { get; set; }
        public string encryptedText { get; set; }

        public void MakeEncryptedText()
        {
            // TODO: Add functionality here
        }

        public void MakeDecryptedText()
        {
            // TODO: Add functionality here
        }

        public void MakeRollingEncryptedText()
        {
            // TODO: Add functionality here
        }

        public void MakeRollingDecryptedText()
        {
            // TODO: Add functionality here
        }

        public void MakeExtraEncryptedText()
        {
            // TODO: Add functionality here
        }

        public void MakeExtraDecryptedText()
        {
            // TODO: Add functionality here
        }

        private string ReadClearTextFromFile(string path)
        {
            return "";
        }

        private string ReadEncryptedTextFromFile(string path)
        {
            return "";
        }

        private void WriteEncryptedTextToFile(string path)
        {
            // TODO: Add functionality here
        }

        private void WriteClearTextToFile(string path)
        {
            // TODO: Add functionality here
        }

    }
}
