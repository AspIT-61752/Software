﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Handler
{
    public class ClassDecryptText
    {
        private List<string> listStringKey;

        ClassDecryptText(List<string> inKey)
        {
            // TODO: Add functionality here
        }

        public string DecryptString(string inString)
        {
            return "";
        }

        private string MakeCharOfCode(string inCharString)
        {
            return "";
        }
    }
}
