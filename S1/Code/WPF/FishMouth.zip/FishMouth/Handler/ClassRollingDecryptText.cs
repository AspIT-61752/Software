﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Handler
{
    public class ClassRollingDecryptText
    {
        private List<string> listStringKey;
        private int keyJump = 3;

        public string RollingDecrypt(string inString)
        {
            return "";
        }

        private string MakeCharOfCode(string inCharString)
        {
            return "";
        }

        private int GetRealRollingKey(int inKey)
        {
            return 0;
        }
    }
}
