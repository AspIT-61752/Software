﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Handler
{
    public class ClassRollingEncryptText
    {
        private List<string> key;
        private ClassDummyText CDT;
        private int keyJump = 0; // Change this later

        public ClassRollingEncryptText(List<string> inKey)
        {
            // TODO: Add functionality here
        }

        private string RollingEncryptString(string inString)
        {
            return "";
        }

        private string MakeCodeOfChar(char aChar)
        {
            return "";
        }
    }
}
