﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class ClassZIP
    {
        public ClassZIP()
        {
            // TODO: Add functionality here
        }

        string CompressString(string inString)
        {
            return "";
        }

        string DecompressString(string inString)
        {
            return "";
        }
    }
}
